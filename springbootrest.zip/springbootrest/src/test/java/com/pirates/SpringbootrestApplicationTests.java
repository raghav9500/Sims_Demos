package com.pirates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
